package com.fir_info;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.Dbconn;

/**
 * Servlet implementation class complainant_action
 */
@WebServlet("/complainant_action")
public class complainant_action extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public complainant_action() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(true);
		String txt_firno=request.getParameter("txt_firno");
		String Pemailid=Dbconn.Pemail;
		String Status=request.getParameter("Status");
		PrintWriter pw=response.getWriter();
		try {
			Connection con=Dbconn.conn();
			Statement st=con.createStatement();
//String Status="Action";
			st.executeUpdate("update tbl_info_fir set Status='"+Status+"',P_Email_ID='"+Pemailid+"' where Fir_No='"+txt_firno+"'");
			pw.println("<script> alert(' FIR Update Successfuly');</script>");
			RequestDispatcher rd = request.getRequestDispatcher("/Show_Data.jsp");
			rd.include(request, response); 
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
