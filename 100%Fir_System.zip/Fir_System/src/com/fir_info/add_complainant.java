package com.fir_info;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Blockchain.ptop;

import com.algo.EncryptDecrypt;
import com.connection.Dbconn;

/**
 * Servlet implementation class add_complainant
 */
@WebServlet("/add_complainant")
public class add_complainant extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public add_complainant() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	public String keyData() {
		StringBuilder ss = new StringBuilder();
		Random r = new Random();
		char ch;

		for (int i = 0; i < 5; i++) {
			ch = (char) (Math.floor(26 * r.nextDouble() + 65));
			ss.append(ch);
		}

		return ss.toString();

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String firno = request.getParameter("txt_firno");
		String txt_firdate = request.getParameter("txt_firdate");
		String txt_Policestationname = request
				.getParameter("txt_Policestationname");
		String txt_username = request.getParameter("txt_username");
		String txt_Uemail = request.getParameter("txt_Uemail");
		String txt_Uaddress = request.getParameter("txt_Uaddress");
		String txt_mobileno = request.getParameter("txt_mobileno");
		String txt_Udescription=request.getParameter("txt_Udescription");
		String txt_Uaccused_Relation = request.getParameter("txt_Uaccused");
		// txt_Aname
		String txt_Aname = request.getParameter("txt_Aname");
		String txt_Aaddress = request.getParameter("txt_Aaddress");
		String txt_Amobile = request.getParameter("txt_Amobile");
		HttpSession session = request.getSession(true);
		PrintWriter pw = response.getWriter();
		String secretKey = keyData();
		try {
			String Policestationname = EncryptDecrypt.encrypt(secretKey,txt_Policestationname);
			String username = EncryptDecrypt.encrypt(secretKey, txt_username);
			String Uemail = EncryptDecrypt.encrypt(secretKey, txt_Uemail);
			String Uaddress = EncryptDecrypt.encrypt(secretKey, txt_Uaddress);
			String mobileno = EncryptDecrypt.encrypt(secretKey, txt_mobileno);
			String U_Relation_accused = EncryptDecrypt.encrypt(secretKey, txt_Uaccused_Relation);
			String Udescription=EncryptDecrypt.encrypt(secretKey, txt_Udescription);
			//
			String Aname = EncryptDecrypt.encrypt(secretKey, txt_Aname);
			String Aaddress = EncryptDecrypt.encrypt(secretKey, txt_Aaddress);
			String Amobile = EncryptDecrypt.encrypt(secretKey, txt_Amobile);
			String data=Policestationname+"#"+username+"#"+Uemail+"#"+Uaddress+"#"+mobileno+"#"+U_Relation_accused+"#"+Udescription+"#"+Aname+"#"+Aaddress+"#"+Amobile;
			int noofnode=4;
			String encdata=firno+"#"+EncryptDecrypt.encrypt(secretKey, data);
			ptop.ptopverify(noofnode,encdata);
			
			String Status="Pending";
			Connection con = Dbconn.conn();
			 PreparedStatement ps = con
			 .prepareStatement("insert into tbl_info_fir(Fir_No,Date_FIR,Police_Station_Info,Complainant_Name,U_Email_ID,U_Address,U_Mobile_No,U_Relation_accused,A_accused,A_Address,A_Mobile_No,Status,Udescription,SecretKey,U_Name) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			 ps.setString(1, firno);
			 ps.setString(2, txt_firdate);
			 ps.setString(3, Policestationname);
			 ps.setString(4, username);
			 ps.setString(5, Uemail);
			 ps.setString(6, Uaddress);
			 ps.setString(7, mobileno);
			 ps.setString(8, U_Relation_accused);
			 ps.setString(9, Aname);
			 ps.setString(10, Aaddress);
			 ps.setString(11, Amobile);
			 ps.setString(12, Status);
			 ps.setString(13, Udescription);
			 ps.setString(14, secretKey);
			 ps.setString(15, username);
			 ps.executeUpdate();

			pw.println("<script> alert(' Add Fir Successfully');</script>");
			RequestDispatcher rd = request
					.getRequestDispatcher("/User_AddFir.jsp");
			rd.include(request, response);

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
