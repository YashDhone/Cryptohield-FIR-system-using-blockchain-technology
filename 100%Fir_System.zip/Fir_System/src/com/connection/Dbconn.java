package com.connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;


public class Dbconn {
	   
	public static String Uname="";
	public static String Uemail="";
	public static String Umobile="";
	public static String Pemail="";
	   public Dbconn() throws SQLException {
        super();
       }

public static Connection conn()throws SQLException,ClassNotFoundException{
	Connection con;
	
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection("jdbc:mysql://localhost/240420_fir_system_application", "root", "admin");
	return (con);
}
}
