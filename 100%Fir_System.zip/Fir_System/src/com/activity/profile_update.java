package com.activity;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.Dbconn;
import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class profile_update
 */
@WebServlet("/profile_update")
public class profile_update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public profile_update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html;charset=UTF-8");
			PrintWriter pw=response.getWriter();
			String Uname,Address,Email,Number,Password;
		
			Uname=request.getParameter("txtName");
			System.out.println("UserName"+Uname);
			Address=request.getParameter("txtAddress");
			System.out.println("Address"+Address);
			String gender=request.getParameter("rdoGender");
			System.out.println("gender"+gender);
			Email=request.getParameter("txtEmail");
			System.out.println("EmailId"+Email);
			Number=request.getParameter("txtContact");
			System.out.println("MobNo"+Number);
			Password=request.getParameter("passPassword");
			System.out.println("Password"+Password);
			
			  try
			  {
				Connection con;
				con = Dbconn.conn();
				
				
				
				Statement st=con.createStatement();
				st.executeUpdate("update userregistration set Umobno='"+Number+"',Upassword='"+Password+"' where Uemail='"+Email+"'");
				{
					System.out.println("OK ");
					pw.println("<script> alert(' Update Profile Successfuly');</script>");
					RequestDispatcher rd = request.getRequestDispatcher("/UserHome.jsp");
					rd.include(request, response); 
				}
				
				
			}
			catch(Exception exc)
			{
				
				exc.printStackTrace();
			}
	}

}
