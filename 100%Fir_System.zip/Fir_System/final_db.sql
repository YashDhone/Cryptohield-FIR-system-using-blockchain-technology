# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     240420_fir_system_application
# Server version:               5.1.73-community
# Server OS:                    Win32
# HeidiSQL version:             5.0.0.3272
# Date/time:                    2024-04-22 18:55:47
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
# Dumping database structure for 240420_fir_system_application
CREATE DATABASE IF NOT EXISTS `240420_fir_system_application` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `240420_fir_system_application`;


# Dumping structure for table 240420_fir_system_application.police_officerregistration
CREATE TABLE IF NOT EXISTS `police_officerregistration` (
  `Uname` text,
  `Uaddress` text,
  `UGender` text,
  `Uemail` text,
  `Umobno` text,
  `Upassword` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table 240420_fir_system_application.police_officerregistration: 1 rows
/*!40000 ALTER TABLE `police_officerregistration` DISABLE KEYS */;
INSERT INTO `police_officerregistration` (`Uname`, `Uaddress`, `UGender`, `Uemail`, `Umobno`, `Upassword`) VALUES ('jitu', 'pune', 'Male', 'jitu@gmail.com', '8888923361', '123');
/*!40000 ALTER TABLE `police_officerregistration` ENABLE KEYS */;


# Dumping structure for table 240420_fir_system_application.tbl_info_fir
CREATE TABLE IF NOT EXISTS `tbl_info_fir` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `Fir_No` text,
  `Date_FIR` text,
  `Police_Station_Info` text,
  `Complainant_Name` text,
  `U_Email_ID` text,
  `U_Address` text,
  `U_Mobile_No` text,
  `U_Relation_accused` text,
  `A_accused` text,
  `A_Address` text,
  `A_Mobile_No` text,
  `Status` text,
  `Udescription` text,
  `SecretKey` text,
  `U_Name` text,
  `P_Email_ID` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

# Dumping data for table 240420_fir_system_application.tbl_info_fir: 4 rows
/*!40000 ALTER TABLE `tbl_info_fir` DISABLE KEYS */;
INSERT INTO `tbl_info_fir` (`id`, `Fir_No`, `Date_FIR`, `Police_Station_Info`, `Complainant_Name`, `U_Email_ID`, `U_Address`, `U_Mobile_No`, `U_Relation_accused`, `A_accused`, `A_Address`, `A_Mobile_No`, `Status`, `Udescription`, `SecretKey`, `U_Name`, `P_Email_ID`) VALUES (1, '1', '2024/01/22 11:54 AM', 'LViUZt/v1Ak=', 'HeHqCBAbAZY=', 'OV9YQlSs4gkwhGqlJ+xnTQ==', 'LViUZt/v1Ak=', '382Ow67XytHPX3AtzSg89g==', 'aolKv0hCpkg=', 'K/rRSdXNTJo=', '+hrMP61id8k=', 'xvcXQ/qfaX14w0NwsdWv9Q==', 'Action', 'uvUpncaU16M=', 'RINPU', 'HeHqCBAbAZY=', 'jitu@gmail.com'), (2, '2', '2024/01/22 13:00 PM', 'mDJ0xXvRKS1jA4p4I3aSLQ==', 'mC3SwUxWVpQ=', 'vnJOhoVrvYUhyO0dvDsFIg==', 'mDJ0xXvRKS2auL1d3qWJYmE4x3oi1mbe13lM5/YEhx4=', 'xnGWLk2L8omT97q6ncMbcg==', 'hC2OI29NnnU=', 'VtmzTMhDJr0=', 'oS0B4xNeIqY=', 'lLgfM0mRclJLpzH0ukcX1A==', 'Action', 'NAf5PSe0DE3lzCOQ3jzFvg==', 'NEUDL', 'mC3SwUxWVpQ=', 'jitu@gmail.com'), (3, '3', '2024/02/09 17:25 PM', 'jGlBxZOd8QQ=', 'DaviuzkPlJg=', 'ReSBgUqC+o+1CEWBlPRlVg==', '1TiaWBsBecA=', '8weAeGWs1JwDADY9HtbYBw==', 'xKwe1wTjPlA=', 'uoX+/tpuvDQ=', 'w3q9u3ZY62U=', 'w3TWkjoUpTywpJJGHRmIHw==', 'Pending', 'ko4gd5ZFYC0=', 'HEAPE', 'DaviuzkPlJg=', 'jitu@gmail.com'), (4, '4', '2024/02/09 18:24 PM', 'UE7n2A5Jq3E=', 'BXT3nYN7pHo=', 'eqa2iyvcXzBgRd3Ej1zvXA==', 'Yu/Yk9iugW0=', 'VjGSIDl9DiA+aXx2cKkWxw==', 'ARcvmhd55tU=', '3XtSex5qIIE=', '93TbrKzJTbk=', 'exOCl8fTHwe5gNLUOeiV5A==', 'Accept', 'ON078D7Pa5s=', 'RPLWT', 'BXT3nYN7pHo=', 'jitu@gmail.com');
/*!40000 ALTER TABLE `tbl_info_fir` ENABLE KEYS */;


# Dumping structure for table 240420_fir_system_application.userregistration
CREATE TABLE IF NOT EXISTS `userregistration` (
  `Uname` text,
  `Uaddress` text,
  `UGender` text,
  `Uemail` text,
  `Umobno` text,
  `Upassword` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

# Dumping data for table 240420_fir_system_application.userregistration: 3 rows
/*!40000 ALTER TABLE `userregistration` DISABLE KEYS */;
INSERT INTO `userregistration` (`Uname`, `Uaddress`, `UGender`, `Uemail`, `Umobno`, `Upassword`) VALUES ('om', 'pune', 'Male', 'om@gmail.com', '9874523610', '123'), ('raj', 'pune', 'Male', 'raj@gmail.com', '9876543210', '123'), ('admin', 'pune', 'Male', 'admin@gmail.com', '7777777777', '123');
/*!40000 ALTER TABLE `userregistration` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
